const { Client, Intents, MessageEmbed, MessageActionRow, MessageSelectMenu, MessageButton } = require('discord.js');

const client = new Client({
    intents: [
        Intents.FLAGS.GUILDS,
        Intents.FLAGS.GUILD_MESSAGES,
        Intents.FLAGS.GUILD_MESSAGE_REACTIONS,
        Intents.FLAGS.GUILD_MEMBERS,
    ],
});

client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {
    if (message.content === '!ticket' && message.member.permissions.has('ADMINISTRATOR')) {
        const embed = new MessageEmbed()
            .setColor('#b71b22')
            .setTitle('Ticket')
            .setImage('')
            .setDescription('**How Can we help u? **')
            .setTimestamp();

        const row = new MessageActionRow()
            .addComponents(
                new MessageSelectMenu()
                    .setCustomId('select')
                    .setPlaceholder(' Get some help ')
                    .addOptions([
                        {
                            label: 'Ticket',
                            description:'Help',
                            emoji: '1196356569672187904',
                            value: 'clan_application',
                        },
                        {
                            label: 'شكوى أو استفسار',
                            description: 'لتقديم شكوى أو استفسار عام',
                            emoji: '1196356569672187904',
                            value: 'complaint_inquiry',
                        },
                    ]),
            );

        await message.channel.send({ embeds: [embed], components: [row] });
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isSelectMenu()) return;

    if (interaction.customId === 'select') {
        const categoryID = '';
        const guild = interaction.guild;
        const user = interaction.user;
        const value = interaction.values[0];
        let ticketType = value === 'clan_application' ? 'Ticket' : 'شكوى-استفسار';

        const ticketChannel = await guild.channels.create(`${ticketType}-${user.username}`, {
            type: 'GUILD_TEXT',
            parent: categoryID,
            permissionOverwrites: [
                {
                    id: guild.id,
                    deny: ['VIEW_CHANNEL'],
                },
                {
                    id: user.id,
                    allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY'],
                },
                {
                    id: client.user.id,
                    allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY'],
                },
            ],
        });

        const ticketEmbed = new MessageEmbed()
            .setColor('#00ff00')
            .setTitle('تذكرة جديدة')
            .addFields(
                { name: 'صاحب التذكرة', value: `${user.tag}`, inline: true },
                { name: 'وقت الفتح', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                { name: 'نوع التذكرة', value: ticketType === 'Ticket' ? 'Help' : 'شكوى/استفسار', inline: true }
            )
            .setTimestamp();

        const closeButton = new MessageActionRow()
            .addComponents(
                new MessageButton()
                    .setCustomId('close_ticket')
                    .setLabel('قفل التذكرة')
                    .setStyle('DANGER'),
            );

        await ticketChannel.send({ embeds: [ticketEmbed], components: [closeButton] });
        await interaction.reply({ content: `تم فتح تذكرتك! اذهب إلى: ${ticketChannel}`, ephemeral: true });
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'close_ticket') {
        await interaction.channel.delete();
    }
});

client.login('')
